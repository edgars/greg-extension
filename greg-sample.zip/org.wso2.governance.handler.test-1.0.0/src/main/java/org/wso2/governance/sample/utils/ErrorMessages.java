package org.wso2.governance.sample.utils;


public final class ErrorMessages {

    public static final String EXAMPLE_EXCEPTION = "Example exception message";

    private ErrorMessages() {
    }
}
