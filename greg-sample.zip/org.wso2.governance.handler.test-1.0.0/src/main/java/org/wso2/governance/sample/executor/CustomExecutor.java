package org.wso2.governance.sample.executor;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.governance.registry.extensions.interfaces.Execution;
import org.wso2.carbon.registry.core.jdbc.handlers.RequestContext;

public class CustomExecutor implements Execution {

	private static final Log log = LogFactory.getLog(CustomExecutor.class);
    private String[] attributes = new String[0];
 
    public void init(Map parameterMap) {
        if (parameterMap != null) {
            String temp = (String) parameterMap.get("attributes");
            if (temp != null) {
                attributes = temp.split(",");
            }
        }
    }
    
    public boolean execute(RequestContext context, String currentState, String targetState) { 
    	if(attributes.length == 0){
    		return false;
    	}
    	String resourcePath = context.getResourcePath().getPath();
    	log.info(resourcePath + " Lifecycle change from : "+currentState + " to :" + targetState);
		return true; 
    	
    	
    }

}
