package org.wso2.governance.sample.validate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.wso2.carbon.governance.api.common.dataobjects.GovernanceArtifact;
import org.wso2.carbon.governance.api.exception.GovernanceException;
import org.wso2.carbon.governance.api.util.GovernanceUtils;
import org.wso2.carbon.governance.registry.extensions.interfaces.CustomValidations;
import org.wso2.carbon.registry.core.RegistryConstants;
import org.wso2.carbon.registry.core.exceptions.RegistryException;
import org.wso2.carbon.registry.core.jdbc.handlers.RequestContext;
import org.wso2.carbon.registry.core.session.UserRegistry;
 
import java.util.Map;

public class CustomValidation  implements CustomValidations {

	private static final Log log = LogFactory.getLog(CustomValidation.class);
    private String[] attributes = new String[0];
 
    public void init(Map parameterMap) {
        if (parameterMap != null) {
            String temp = (String) parameterMap.get("attributes");
            if (temp != null) {
                attributes = temp.split(",");
            }
        }
    }
 
    public boolean validate(RequestContext context) {
        if (attributes.length == 0) {
            return true;
        }
        String resourcePath = context.getResourcePath().getPath();
        int index = resourcePath.indexOf(RegistryConstants.GOVERNANCE_REGISTRY_BASE_PATH);
        if (index < 0) {
            log.warn("Unable to use Validator For Resource Path: " + resourcePath);
            return false;
        }
        index += RegistryConstants.GOVERNANCE_REGISTRY_BASE_PATH.length();
        if (resourcePath.length() <= index) {
            log.warn("Unable to use Validator For Resource Path: " + resourcePath);
            return false;
        }
        resourcePath = resourcePath.substring(index);
        try {
            UserRegistry registry = ((UserRegistry) context.getSystemRegistry())
                    .getChrootedRegistry(RegistryConstants.GOVERNANCE_REGISTRY_BASE_PATH);
            GovernanceArtifact governanceArtifact =
                    GovernanceUtils.retrieveGovernanceArtifactByPath(registry, resourcePath);
            for (String attribute : attributes) {
                if (!validateAttribute(governanceArtifact, attribute)) {
                    return false;
                }
            }
        } catch (RegistryException e) {
            log.error("Unable to obtain registry instance", e);
        }
        return true;
    }
 
    protected boolean validateAttribute(GovernanceArtifact governanceArtifact, String attribute)
            throws GovernanceException {
        return (governanceArtifact.getAttribute(attribute) != null);
    }

}
