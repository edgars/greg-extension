
package org.wso2.governance.sample.handler;

import org.wso2.carbon.registry.core.exceptions.RegistryException;
import org.wso2.carbon.registry.core.jdbc.handlers.Handler;
import org.wso2.carbon.registry.core.jdbc.handlers.RequestContext;
import org.wso2.governance.sample.utils.ErrorMessages;


public class SampleHandler extends Handler {


	/**
	 * This is the default constructor.
	 */
	public SampleHandler() {
		super();
	}

	public void delete(RequestContext requestContext) throws RegistryException {
		throw new RegistryException(
						ErrorMessages.EXAMPLE_EXCEPTION);
	}
}
